"use strict";



$("#ContactForm").submit(function(){
  alert("Yor Message Has been sent");
});
